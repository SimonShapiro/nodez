nodez
=====

An implementation of a conceptual modelling tool based on the neo4j graph database
