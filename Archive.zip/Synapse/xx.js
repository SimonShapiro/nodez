x={
hello:{one:"two"}}

console.log(("hello" in x))
